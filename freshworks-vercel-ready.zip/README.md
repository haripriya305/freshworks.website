# FreshWorks — Full-Stack Support Platform (Vercel-ready)

This project contains the static frontend (`public/`, copied from `frontend/`) and the Express REST API (`backend/`). Vercel serves files in `public/` and runs the Express app exported by the root `index.js`.

## Deploy to Vercel

1. Extract this ZIP. **Upload the contents of this folder to the GitHub repository root** (so `index.js`, `package.json`, `vercel.json`, `backend/`, and `public/` are directly at the repository root). Do not upload an extra parent folder around these files.
2. In Vercel, import that GitHub repository. Set Root Directory to `./` and Framework Preset to Express (or leave automatic detection enabled). Do not set a custom Build Command or Output Directory.
3. In Project → Settings → Environment Variables, add `JWT_SECRET` with a long, random secret value.
4. Redeploy the project.
5. Test `https://YOUR-SITE.vercel.app/` and `https://YOUR-SITE.vercel.app/api/health`. The health endpoint should return JSON with `status: ok`.

## Database

Demo mode is enabled when no database variables are configured. It uses an in-memory store; new registrations and contact messages can be lost when a serverless instance restarts. For persistent data, configure `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, and `DB_SSL=true` for a supported MySQL provider.

Demo logins: `admin@freshworks-demo.com` / `Admin@123`, and `dev@freshworks-demo.com` / `Agent@123`. Change the JWT secret before production use.

## Run locally

```bash
npm install
# Optional: copy .env.example to .env and configure environment variables
npm start
```

The local server runs at `http://localhost:5000`.

## Project structure

```text
index.js           Vercel Express entry point
vercel.json        Express framework configuration
public/            Static files served by Vercel
frontend/          Editable frontend source
backend/           Express API, routes, controllers, models, database
package.json       Dependencies and scripts
```
